/* =============================================================
   PORTFOLIO — আপনার কাজের নমুনা এখানে যোগ করুন / বদলান
   -------------------------------------------------------------
   1) ছবিটি  images/portfolio/  ফোল্ডারে আপলোড করুন (jpg / png / webp)
   2) নিচের তালিকায় একটি লাইন যোগ করুন, যেমন:
      { img: "images/portfolio/health-camp.jpg", cat: "poster", en: "Health Camp Poster", bn: "হেলথ ক্যাম্পের পোস্টার" },
   cat (ক্যাটাগরি) হবে এর যেকোনো একটি:
      website | app | poster | social | google | print
   ক্রম অনুযায়ী ওয়েবসাইটে দেখাবে। যত খুশি ছবি যোগ করতে পারেন।
   ============================================================= */
window.PORTFOLIO = [
  { img: "images/portfolio/website-clinic.svg",   cat: "website", en: "Clinic Website — Online Appointment", bn: "ক্লিনিক ওয়েবসাইট — অনলাইন অ্যাপয়েন্টমেন্ট" },
  { img: "images/portfolio/poster-healthday.svg", cat: "poster",  en: "World Health Day Poster",             bn: "বিশ্ব স্বাস্থ্য দিবসের পোস্টার" },
  { img: "images/portfolio/app-clinic.svg",       cat: "app",     en: "Clinic & OPD Management Software",   bn: "ক্লিনিক ও OPD ম্যানেজমেন্ট সফটওয়্যার" },
  { img: "images/portfolio/social-grid.svg",      cat: "social",  en: "Doctor's Instagram Feed",             bn: "ডাক্তারের ইনস্টাগ্রাম ফিড" },
  { img: "images/portfolio/google-profile.svg",   cat: "google",  en: "Clinic Google Business Profile",      bn: "ক্লিনিকের গুগল বিজনেস প্রোফাইল" },
  { img: "images/portfolio/print-prescription.svg", cat: "print", en: "Prescription Pad & Visiting Card",    bn: "প্রেসক্রিপশন প্যাড ও ভিজিটিং কার্ড" },
  { img: "images/portfolio/website-pharmacy.svg", cat: "website", en: "Online Pharmacy Website",             bn: "অনলাইন ফার্মেসি ওয়েবসাইট" },
  { img: "images/portfolio/poster-health.svg",    cat: "poster",  en: "Free Health Camp Poster",             bn: "ফ্রি হেলথ ক্যাম্পের পোস্টার" },
  { img: "images/portfolio/print-banner.svg",     cat: "print",   en: "Diagnostic Centre Flex Banner",       bn: "ডায়াগনস্টিক সেন্টারের ফ্লেক্স ব্যানার" }
];
